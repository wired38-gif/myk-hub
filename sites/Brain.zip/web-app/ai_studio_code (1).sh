cd ~/Desktop/myk-brain-workspace-main # Or your exported folder name
chmod +x setup.sh && ./setup.sh